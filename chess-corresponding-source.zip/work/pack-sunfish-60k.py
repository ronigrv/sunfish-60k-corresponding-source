"""Pack the local attributed GPL fork as standalone Python; no upload."""
import lzma
import pathlib
import sys

sys.path.insert(0, "work/chess-minifier-deps")
import python_minifier

source = pathlib.Path("work/sunfish-60k.py").read_text(encoding="utf8")
minified = python_minifier.minify(source, rename_globals=True,
                                   remove_literal_statements=True, hoist_literals=False,
                                   preserve_globals=["choose_game"])
filters = [{"id":lzma.FILTER_LZMA1, "dict_size":1 << 20, "lc":3, "lp":0, "pb":0}]
packed = lzma.compress(minified.encode(), format=lzma.FORMAT_ALONE, filters=filters)
escaped = b"".join((b"\\x%02x" % value) if value in (0, 10, 13, 39, 92)
                   else bytes([value]) for value in packed)
program = b"# coding: latin-1\nimport lzma\nexec(lzma.decompress('" + escaped + b"'.encode('latin1')))\n"
assert len(program) <= 4096
assert lzma.decompress(packed).decode() == minified
compile(program, "main.py", "exec")
out = pathlib.Path("outputs/sunfish-60k-main.py")
out.write_bytes(program)
print("GPL upstream credited in source; packed bytes", len(program))
