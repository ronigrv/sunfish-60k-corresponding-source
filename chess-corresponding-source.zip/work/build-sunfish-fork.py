"""Local GPL Sunfish experiment: preserve source credit; do not submit."""
import pathlib
import re

upstream = pathlib.Path("work/sunfish-upstream-repo/nnue_4k/pst_entry.py")
src = upstream.read_text(encoding="utf8")
src = src[src.index("import os\n"):]
src = re.sub(r"(?ms)^\s*# minifier-hide start\n.*?^\s*# minifier-hide end\n", "\n", src)
src = src[:src.index("\nhist = [from_board(initial)]")]
old = "if self.nodes % 2048 == 0 and time.time() > self.deadline: raise Stop"
assert old in src
src = src.replace(old, "if self.nodes % 2048 == 0 and self.nodes >= 50000: raise Stop")
driver = '''
# Competition adapter by Roni's agent. Engine: Sunfish by Thomas Dybdahl Ahle
# and contributors, GPL-3.0-only, commit e396948acbd80cdcbad3dccfb07e878fba9df8f4.
import json
import urllib.request

def choose_game(game):
    history = [from_board(initial)]
    for ply, word in enumerate(game["moves"]):
        i, j = parse(word[:2]), parse(word[2:4])
        if ply % 2:
            i, j = 119-i, 119-j
        history.append(history[-1].move(Move(i,j,word[4:].upper())))
    searcher = Searcher()
    legal = set(game["legal_moves"])
    best = None
    candidate = None
    last_depth = 1
    try:
        for depth, gamma, score, move in searcher.search(history):
            if depth > last_depth:
                best = candidate or best
                last_depth = depth
            if score >= gamma and move:
                i, j = move.i, move.j
                if len(game["moves"]) % 2:
                    i, j = 119-i, 119-j
                text = render(i) + render(j) + move.prom.lower()
                if text in legal:
                    candidate = text
    except Stop:
        pass
    return best or candidate or min(legal)

def send(base,path,body):
    req=urllib.request.Request(base+path,json.dumps(body).encode(),
                               {"content-type":"application/json"})
    with urllib.request.urlopen(req,timeout=30) as response:
        return json.load(response)

def run():
    base=os.environ["MAKEFUN_ENV_URL"].rstrip("/")
    while True:
        game=send(base,"/game",{})
        if game["status"]=="done": return
        while game["status"]=="your_move":
            game=send(base,"/move",{"game":game["game"],"move":choose_game(game)})

if __name__ == "__main__":
    run()
'''
out = pathlib.Path("work/sunfish-experiment.py")
out.write_text(src + driver, encoding="utf8", newline="\n")
print("Generated local Sunfish GPL experiment", out)
