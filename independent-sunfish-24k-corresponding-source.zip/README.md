# Independent experimental Sunfish derivative

SPDX-License-Identifier: GPL-3.0-only

Sunfish by Thomas Ahle and contributors:
https://github.com/thomasahle/sunfish
Exact upstream commit: e396948acbd80cdcbad3dccfb07e878fba9df8f4.
The original nnue_4k/pst_entry.py is preserved under upstream/nnue_4k/.
COPYING and upstream/LICENSE.md contain the exact full upstream GPLv3 license.
This adaptation and executable are GPL-3.0-only. The separately vendored
python-minifier 3.2.0 build tool by Daniel Flook retains its MIT license and
distribution metadata under build-tools/.

The repository intended for serving this corresponding-source package is:
https://github.com/ronigrv/sunfish-60k-corresponding-source
The party distributing the executable must verify access to its exact
corresponding source and satisfy applicable GPL obligations before conveying it.

All executable code and data are contained in main.py. The search uses a fixed
24,000-node budget, full game history, legal root filtering and deterministic
completed-depth selection. It uses no wall-clock move decisions, model calls
or runtime source files beyond main.py.

To reproduce with CPython 3.12.5 and the included python-minifier package:

    python -B build.py main.reproduced.py

No package installation or network access is needed. build.py assembles the
editable engine.py from the pinned upstream plus search.py and driver.py,
minifies it to minified.py, then packs it with standard-library LZMA and base85.
The output path above preserves main.py. A separate temporary output directory
was used for local verification; the rebuilt executable matched main.py exactly:

    bytes: 4018
    SHA-256: 9912732c57135f6629bdab047195dd375f646d8f0cd138e8594bd46839fd36e4

The authored search comment was privacy-sanitized in the public copies of
search.py and engine.py; executable behavior and minified.py remain unchanged.
FILES.sha256 inventories the staged files. No caches, credentials, transcripts,
Git internals or personal session logs are part of this package.

Local development checks covered 500 legality/history positions, four tactical
cases and repeated opening decisions before the final probe-guard correction.
Both longer desktop gauntlet runs were stopped externally by a collaborating
coordinator and were incomplete. These documented checks do not establish an
official sandbox grade, timing guarantee, full-trial replay result or
superiority over the official baseline.

Preserve the upstream attribution and license notices when distributing this
work, and provide the corresponding editable source and build materials under
the applicable GPL-3.0-only terms.
