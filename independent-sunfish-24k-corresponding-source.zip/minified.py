b=sorted
a=tuple
S=max
P=enumerate
O=range
N=sum
G=abs
from itertools import count
from collections import namedtuple as T
U={'P':100,'N':280,'B':320,'R':479,'Q':929,'K':60000}
D={'P':(0,0,0,0,0,0,0,0,78,83,86,73,102,82,85,90,7,29,21,44,40,31,44,7,-17,16,-2,15,14,0,15,-13,-26,3,10,9,6,1,0,-23,-22,9,5,-11,-10,-2,3,-19,-31,8,-7,-37,-36,-14,3,-31,0,0,0,0,0,0,0,0),'N':(-66,-53,-75,-75,-10,-55,-58,-70,-3,-6,100,-36,4,62,-4,-14,10,67,1,74,73,27,62,-2,24,24,45,37,33,41,25,17,-1,5,31,21,22,35,2,0,-18,10,13,22,18,15,11,-14,-23,-15,2,0,2,0,-23,-20,-74,-23,-26,-24,-19,-35,-22,-69),'B':(-59,-78,-82,-76,-23,-107,-37,-50,-11,20,35,-42,-39,31,2,-22,-9,39,-32,41,52,-10,28,-14,25,17,20,34,26,25,15,10,13,10,17,23,17,16,0,7,14,25,24,15,8,25,20,15,19,20,11,6,7,6,20,16,-7,2,-15,-12,-14,-15,-10,-10),'R':(35,29,33,4,37,33,56,50,55,29,56,67,55,62,34,60,19,35,28,33,45,27,25,15,0,5,16,13,18,-4,-9,-6,-28,-35,-16,-21,-13,-29,-46,-30,-42,-28,-42,-25,-25,-35,-26,-46,-53,-38,-31,-26,-29,-43,-44,-53,-30,-24,-18,5,-2,-18,-31,-32),'Q':(6,1,-8,-104,69,24,88,26,14,32,60,-10,20,76,57,24,-2,43,32,60,72,63,43,2,1,-16,22,17,25,20,-13,-6,-14,-15,-2,-5,-1,-10,-20,-22,-30,-6,-13,-11,-16,-11,-16,-27,-36,-18,0,-19,-15,-15,-21,-38,-39,-30,-31,-13,-31,-36,-34,-42),'K':(4,54,47,-99,-99,60,83,-62,-32,10,55,56,56,55,10,3,-62,12,-57,44,-67,28,37,-31,-55,50,11,-4,-19,13,0,-49,-55,-43,-52,-28,-51,-47,-8,-50,-47,-42,-43,-79,-64,-32,-29,-32,-4,3,-14,-50,-57,-18,13,4,17,30,-3,-14,6,-1,40,18)}
for(J,c)in D.items():d=lambda row:(0,)+a(A+U[J]for A in row)+(0,);D[J]=N((d(c[A*8:A*8+8])for A in O(8)),());D[J]=(0,)*20+D[J]+(0,)*20
e,f=D['K'],a(U['K']+70-10*(G(2*(A//10)-11)+G(2*(A%10)-9))for A in O(120))
Q=47923
F=69290
I,K,L,M=91,98,21,28
h='         \n         \n rnbqkbnr\n pppppppp\n ........\n ........\n ........\n ........\n PPPPPPPP\n RNBQKBNR\n         \n         \n'
A,B,E,C=-10,1,10,-1
g={'P':(A,A+A,A+C,A+B),'N':(A+A+B,B+A+B,B+E+B,E+E+B,E+E+C,C+E+C,C+A+C,A+A+C),'B':(A+B,E+B,E+C,A+C),'R':(A,B,E,C),'Q':(A,B,E,C,A+B,E+B,E+C,A+C),'K':(A,B,E,C,A+B,E+B,E+C,A+C)}
i=40
j=140
H=T('Move','i j prom')
class R(T('Position','board score wc bc ep kp')):
	def __hash__(A):return hash((A.board,A.wc,A.bc,A.ep,A.kp))
	def __eq__(A,o):return A.board==o.board and A.ep==o.ep and A.kp==o.kp and A.wc==o.wc and A.bc==o.bc
	def __ne__(A,o):return not A.__eq__(o)
	def gen_moves(D):
		for(F,J)in P(D.board):
			if J not in'PNBRQK':continue
			for G in g[J]:
				for E in count(F+G,G):
					N=D.board[E]
					if N in' \nPNBRQK':break
					if J=='P':
						if G in(A,A+A)and N!='.':break
						if G==A+A and(F<I+A or D.board[F+A]!='.'):break
						if G in(A+C,A+B)and N=='.'and E not in(D.ep,D.kp,D.kp-1,D.kp+1):break
						if L<=E<=M:
							for O in'NBRQ':yield H(F,E,O)
							break
					yield H(F,E,'')
					if J in'PNK'or N in'pnbrqk':break
					if F==I and D.board[E+B]=='K'and D.wc[0]:yield H(E+B,E+C,'')
					if F==K and D.board[E+C]=='K'and D.wc[1]:yield H(E+C,E+B,'')
	def rotate(A,nullmove=False):B=nullmove;return R(A.board[::-1].swapcase(),-A.score,A.bc,A.wc,119-A.ep if A.ep and not B else 0,119-A.kp if A.kp and not B else 0)
	def move(F,move):
		D,C,S=move;Q,V=F.board[D],F.board[C];H=lambda board,i,p:board[:i]+p+board[i+1:];B=F.board;J,N,P,O=F.wc,F.bc,0,0;T=F.score+F.value(move);B=H(B,C,B[D]);B=H(B,D,'.');J=J[0]and D!=I,J[1]and D!=K;N=N[0]and C!=M,N[1]and C!=L
		if Q=='K':
			J=False,False
			if G(C-D)==2:O=(D+C)//2;U=I if C<D else K;B=H(B,U,'.');B=H(B,O,'R')
		if Q=='P':
			if L<=C<=M:B=H(B,C,S)
			if C-D==2*A:P=D+A
			if C==F.ep:B=H(B,C+E,'.')
		return R(B[::-1].swapcase(),-T,N,J,119-P if P else 0,119-O if O else 0)
	def value(F,move):
		C,A,N=move;H,J=F.board[C],F.board[A];B=D[H][A]-D[H][C]
		if J in'pnbrqk':B+=D[J.upper()][119-A]
		if G(A-F.kp)<2:B+=D['K'][119-A]
		if H=='K'and G(C-A)==2:B+=D['R'][(C+A)//2];B-=D['R'][I if A<C else K]
		if H=='P':
			if L<=A<=M:B+=D[N][A]-D['P'][A]
			if A==F.ep:B+=D['P'][119-(A+E)]
		return B
	def king_capture(A):return next((B for B in A.gen_moves()if A.board[B.j]=='k'or G(B.j-A.kp)<2),None)
k=24000
class V(Exception):0
class l:
	def __init__(A):A.moves={}
	def bound(C,pos,gamma,depth,root=False):
		H=root;D=gamma;B=depth;A=pos;C.nodes+=1
		if C.nodes>k:raise V
		B=S(B,0)
		if A.score<=-Q:return-F
		N=A,B,H;K,L=C.table.get(N,(-F,F))
		if K>=D:return K
		if L<D:return L
		if not H and B and A in C.history:return 0
		E=-F;I=C.moves.get(A);J=B==0 and A.rotate(True).king_capture();O=-F if J or H else i-B*j
		def U():
			if not H and B>2 and G(A.score)<500 and any(B in A.board for B in'RBNQ'):yield(None,-C.bound(A.rotate(True),1-D,B-3))
			if not B and not J:yield(None,A.score)
			if I and A.value(I)>=O:yield(I,-C.bound(A.move(I),1-D,B-1))
			R=b(((A.value(B),B)for B in(C.legal if H else A.gen_moves())),reverse=True)
			for(S,(E,K))in P(R):
				if K==I:continue
				if E<O:break
				if not J and not H and B<=1 and A.score+E<D:yield(None,F if E>=Q else A.score+E);break
				M=B>2 and S>2 and E<60;N=A.move(K);L=-C.bound(N,1-D,B-1-M)
				if M and L>=D:L=-C.bound(N,1-D,B-1)
				yield(K,L)
		R=False
		for(M,T)in U():
			E=S(E,T);R|=M is not None and T>-F
			if E>=D:
				if M and B:C.moves[A]=M
				break
		if(B or J)and not R and all(A.move(B).king_capture()for B in A.gen_moves()):E=-Q if A.rotate(True).king_capture()else 0
		C.table[N]=(E,L)if E>=D else(K,E);return E
	def choose(A,history,legal):
		K=history;E=legal;A.nodes,A.table=0,{};A.history=set(K[:-1]);A.legal=E;D=K[-1]
		if A.moves.get(D)not in E:A.moves.pop(D,None)
		G=E[0];H=0
		try:
			for L in O(1,64):
				B,C=-F,F;I=G
				for M in O(40):
					J=A.bound(D,H,L,True)
					if J>=H:B=S(B,J);I=A.moves.get(D,I)
					else:C=min(C,J)
					if B>C:break
					if B>=C-15:G=I;break
					H=(B+C+1)//2
		except V:pass
		if len(A.moves)>40000:A.moves.clear()
		return G
import json as W,os,urllib.request
def X(c):return 91+ord(c[0])-97-10*(int(c[1])-1)
def Y(uci,black):B=black;A=uci;C,D=X(A[:2]),X(A[2:4]);return H(119-C if B else C,119-D if B else D,A[4:].upper())
def m(board):A=board;B=N(D[A][B]if A.isupper()else-D[A.upper()][119-B]for(B,A)in P(A)if A.isalpha());return R(A,B,(True,True),(True,True),0,0)
def n(g,searcher):
	B=g['fen'].split()[0];F=N(A.isupper()for A in B)==1 or N(A.islower()for A in B)==1;D['K']=f if F else e;A=[m(h)]
	for(G,H)in P(g['moves']):A.append(A[-1].move(Y(H,G%2)))
	C=b(g['legal_moves']);E=[Y(A,len(g['moves'])%2)for A in C];return C[E.index(searcher.choose(A,E))]
def Z(path,body):
	A=urllib.request.Request(os.environ['MAKEFUN_ENV_URL']+path,W.dumps(body).encode(),{'Content-Type':'application/json'})
	with urllib.request.urlopen(A)as B:return W.load(B)
def o():
	while True:
		A=Z('/game',{})
		if A['status']=='done':break
		B=l()
		while A['status']=='your_move':A=Z('/move',{'game':A['game'],'move':n(A,B)})
		print(A['game'],A['outcome'],A['reason'],flush=True)
if __name__=='__main__':o()