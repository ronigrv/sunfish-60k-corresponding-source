# SPDX-License-Identifier: GPL-3.0-only
import json, os, urllib.request

def parse(c):
    return 91+ord(c[0])-97-10*(int(c[1])-1)

def decode(uci, black):
    i, j = parse(uci[:2]), parse(uci[2:4])
    return Move(119-i if black else i, 119-j if black else j, uci[4:].upper())

def from_board(board):
    score = sum(pst[p][i] if p.isupper() else -pst[p.upper()][119-i]
                for i, p in enumerate(board) if p.isalpha())
    return Position(board, score, (True, True), (True, True), 0, 0)

def choose_game(g, searcher):
    # Fix the king table for this entire search, then rescore its replay consistently.
    pieces = g["fen"].split()[0]
    bare = sum(c.isupper() for c in pieces)==1 or sum(c.islower() for c in pieces)==1
    pst["K"] = K_END if bare else K_MID
    # Replay the complete public history, including the eight opening plies.
    history = [from_board(initial)]
    for ply, uci in enumerate(g["moves"]):
        history.append(history[-1].move(decode(uci, ply%2)))
    ucis = sorted(g["legal_moves"])
    legal = [decode(u, len(g["moves"])%2) for u in ucis]
    return ucis[legal.index(searcher.choose(history, legal))]

def post(path, body):
    req = urllib.request.Request(os.environ["MAKEFUN_ENV_URL"]+path,
          json.dumps(body).encode(), {"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as response:
        return json.load(response)

def main():
    while True:
        g = post("/game", {})
        if g["status"] == "done":
            break
        searcher = Searcher()
        while g["status"] == "your_move":
            g = post("/move", {"game": g["game"], "move": choose_game(g, searcher)})
        print(g["game"], g["outcome"], g["reason"], flush=True)

if __name__ == "__main__":
    main()
