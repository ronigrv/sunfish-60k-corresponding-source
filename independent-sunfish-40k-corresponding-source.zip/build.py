"""Reproduce the complete editable engine and UTF-8 packed main.py, stdlib only."""
import ast
import base64
import hashlib
import lzma
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
PIN = "e396948acbd80cdcbad3dccfb07e878fba9df8f4"
upstream = ROOT / "upstream" / "nnue_4k" / "pst_entry.py"
tree = ast.parse(upstream.read_text(encoding="utf-8"))
selected = []
for node in tree.body:
    if isinstance(node, ast.ClassDef) and node.name == "Stop":
        break
    if isinstance(node, (ast.Import, ast.ImportFrom)):
        if isinstance(node, ast.ImportFrom):
            selected.append(node)
        continue
    if isinstance(node, ast.Assign):
        names = [x.id for x in node.targets if isinstance(x, ast.Name)]
        if any(x in names for x in ("__version__", "version", "opt_ranges",
                                   "EVAL_ROUGHNESS", "PROBE_CAP", "LMR", "TABLE_SIZE")):
            continue
    selected.append(node)

class Strip(ast.NodeTransformer):
    def visit_Expr(self, node):
        return None if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str) else node

core = ast.unparse(Strip().visit(ast.Module(body=selected, type_ignores=[])))
source = core+"\n"+(ROOT/"search.py").read_text()+"\n"+(ROOT/"driver.py").read_text()
(ROOT/"engine.py").write_text(source, encoding="utf-8", newline="\n")
sys.path.insert(0, str(ROOT/"build-tools"))
import python_minifier
code = python_minifier.minify(source, rename_globals=True, hoist_literals=False)
(ROOT/"minified.py").write_text(code, encoding="utf-8", newline="\n")
compressed = lzma.compress(code.encode(), format=lzma.FORMAT_ALONE,
    filters=[{"id": lzma.FILTER_LZMA1, "preset": 9 | lzma.PRESET_EXTREME, "pb": 0}])
payload = base64.b85encode(compressed).decode()
packed = "# SPDX-License-Identifier: GPL-3.0-only\nimport lzma,base64\nexec(lzma.decompress(base64.b85decode("+repr(payload)+")))\n"
target = pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/"main.generated.py"
target.write_text(packed, encoding="utf-8", newline="\n")
print("source",len(source.encode()),"compressed",len(compressed),"main",len(packed.encode()),
      "sha256",hashlib.sha256(packed.encode()).hexdigest())
assert len(packed.encode()) <= 4096
