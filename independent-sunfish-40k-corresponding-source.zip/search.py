# SPDX-License-Identifier: GPL-3.0-only
# Independently adapted Sunfish search, 2026-11-10.
# The board and PST remain Thomas Ahle and contributors' pinned Sunfish.
# Local-comparison derivative of the independently authored 24k experiment.
LIMIT = 40000
class Stop(Exception):
    pass

class Searcher:
    def __init__(self):
        self.moves = {}

    def bound(self, pos, gamma, depth, root=False):
        self.nodes += 1
        if self.nodes > LIMIT:
            raise Stop
        depth = max(depth, 0)
        if pos.score <= -MATE_LOWER:
            return -MATE_UPPER
        key = pos, depth, root
        lo, hi = self.table.get(key, (-MATE_UPPER, MATE_UPPER))
        if lo >= gamma:
            return lo
        if hi < gamma:
            return hi
        if not root and depth and pos in self.history:
            return 0
        best = -MATE_UPPER
        killer = self.moves.get(pos)
        checked = depth == 0 and pos.rotate(True).king_capture()
        threshold = -MATE_UPPER if checked or root else QS-depth*QS_A
        def candidates():
            if not root and depth > 2 and abs(pos.score) < 500 and any(c in pos.board for c in "RBNQ"):
                yield None, -self.bound(pos.rotate(True), 1-gamma, depth-3)
            if not depth and not checked:
                yield None, pos.score
            if killer and pos.value(killer) >= threshold:
                yield killer, -self.bound(pos.move(killer), 1-gamma, depth-1)
            ordered = sorted(((pos.value(m), m) for m in (self.legal if root else pos.gen_moves())), reverse=True)
            for index, (value, move) in enumerate(ordered):
                if move == killer:
                    continue
                if value < threshold:
                    break
                if not checked and not root and depth <= 1 and pos.score+value < gamma:
                    yield None, MATE_UPPER if value >= MATE_LOWER else pos.score+value
                    break
                reduction = depth > 2 and index > 2 and value < 60
                child = pos.move(move)
                score = -self.bound(child, 1-gamma, depth-1-reduction)
                if reduction and score >= gamma:
                    score = -self.bound(child, 1-gamma, depth-1)
                yield move, score
        live = False
        for move, score in candidates():
            best = max(best, score)
            live |= move is not None and score > -MATE_UPPER
            if best >= gamma:
                if move and depth:
                    self.moves[pos] = move
                break
        if (depth or checked) and not live and all(pos.move(m).king_capture() for m in pos.gen_moves()):
            best = -MATE_LOWER if pos.rotate(True).king_capture() else 0
        self.table[key] = (best, hi) if best >= gamma else (lo, best)
        return best

    def choose(self, history, legal):
        self.nodes, self.table = 0, {}
        self.history = set(history[:-1])
        self.legal = legal
        pos = history[-1]
        # Never let an earlier game's or a non-legal root killer escape the root filter.
        if self.moves.get(pos) not in legal:
            self.moves.pop(pos, None)
        best = legal[0]
        gamma = 0
        try:
            for depth in range(1, 64):
                lower, upper = -MATE_UPPER, MATE_UPPER
                candidate = best
                for probe in range(40):
                    score = self.bound(pos, gamma, depth, True)
                    if score >= gamma:
                        lower = max(lower, score)
                        candidate = self.moves.get(pos, candidate)
                    else:
                        upper = min(upper, score)
                    if lower > upper:
                        break
                    if lower >= upper-15:
                        # Only a converged, non-crossing bracket can replace the move.
                        best = candidate
                        break
                    gamma = (lower+upper+1)//2
                # Commit only after a whole depth, not a partial fail-high probe.
        except Stop:
            pass
        if len(self.moves) > 40000:
            self.moves.clear()
        return best
