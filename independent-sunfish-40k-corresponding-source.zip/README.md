# Independent experimental 40k-node Sunfish derivative

SPDX-License-Identifier: GPL-3.0-only

Sunfish by Thomas Ahle and contributors:
https://github.com/thomasahle/sunfish
Exact upstream commit: e396948acbd80cdcbad3dccfb07e878fba9df8f4.
The original nnue_4k/pst_entry.py is preserved under upstream/nnue_4k/.
COPYING and upstream/LICENSE.md contain the exact full upstream GPLv3 license.
This adaptation and executable are GPL-3.0-only. The separately vendored
python-minifier 3.2.0 build tool by Daniel Flook retains its MIT license and
distribution metadata under build-tools/.

This is a local-comparison derivative of this session's independently authored
24,000-node experiment, repository commit
04481c446b85ba03f560316721bfa11acd05f583.
Its upstream provenance and original 24k history are preserved. The only
implementation change is the fixed search budget from 24,000 to 40,000 nodes;
the attempted 40,001st node raises the deterministic stop.
A larger budget is not evidence of improved playing strength.

The repository intended for serving this corresponding-source package is:
https://github.com/ronigrv/sunfish-60k-corresponding-source
The party distributing the executable must verify access to its exact
corresponding source and satisfy applicable GPL obligations before conveying it.

All executable code and data are contained in main.py. The search uses a fixed
40,000-node budget, full game history, legal root filtering and deterministic
completed-depth selection. It uses no wall-clock move decisions, model calls
or runtime source files beyond main.py.

To reproduce with CPython 3.12.5 and the included python-minifier package:

    python -B build.py main.reproduced.py

No package installation or network access is needed. build.py assembles the
editable engine.py from the pinned upstream plus search.py and driver.py,
minifies it to minified.py, then packs it with standard-library LZMA and base85.
The output path above preserves main.py. A separate temporary output directory
was used for local verification; the rebuilt executable matched main.py exactly:

    bytes: 4016
    SHA-256: 250d9e44f755fbbbdb1df7f85d50aee856354f43d448e059968685e5cbea3ff1

The authored search comment was privacy-sanitized in the public copies of
search.py and engine.py; executable behavior and minified.py remain unchanged.
FILES.sha256 inventories the staged files. No caches, credentials, transcripts,
Git internals or personal session logs are part of this package.

Position checks on the exact executable used the official kit's legal-move
oracle after 8- and 9-ply histories. Both choices were legal and matched across
PYTHONHASHSEED=1 and 987654, including identical node counts. The readable source
made the same choices. Each stopped at the attempted 40,001st node. These two
fixture checks are not game matches or a full-trial replay.
The 24k predecessor's development checks and interrupted gauntlets are not
evidence of this 40k variant's strength or timing. Documented checks do not establish an official
sandbox grade, timing guarantee, full-trial replay result or superiority over
the official 50k-node baseline.

Preserve the upstream attribution and license notices when distributing this
work, and provide the corresponding editable source and build materials under
the applicable GPL-3.0-only terms.
