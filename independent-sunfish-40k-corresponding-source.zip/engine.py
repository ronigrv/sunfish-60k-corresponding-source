from itertools import count
from collections import namedtuple
piece = {'P': 100, 'N': 280, 'B': 320, 'R': 479, 'Q': 929, 'K': 60000}
pst = {'P': (0, 0, 0, 0, 0, 0, 0, 0, 78, 83, 86, 73, 102, 82, 85, 90, 7, 29, 21, 44, 40, 31, 44, 7, -17, 16, -2, 15, 14, 0, 15, -13, -26, 3, 10, 9, 6, 1, 0, -23, -22, 9, 5, -11, -10, -2, 3, -19, -31, 8, -7, -37, -36, -14, 3, -31, 0, 0, 0, 0, 0, 0, 0, 0), 'N': (-66, -53, -75, -75, -10, -55, -58, -70, -3, -6, 100, -36, 4, 62, -4, -14, 10, 67, 1, 74, 73, 27, 62, -2, 24, 24, 45, 37, 33, 41, 25, 17, -1, 5, 31, 21, 22, 35, 2, 0, -18, 10, 13, 22, 18, 15, 11, -14, -23, -15, 2, 0, 2, 0, -23, -20, -74, -23, -26, -24, -19, -35, -22, -69), 'B': (-59, -78, -82, -76, -23, -107, -37, -50, -11, 20, 35, -42, -39, 31, 2, -22, -9, 39, -32, 41, 52, -10, 28, -14, 25, 17, 20, 34, 26, 25, 15, 10, 13, 10, 17, 23, 17, 16, 0, 7, 14, 25, 24, 15, 8, 25, 20, 15, 19, 20, 11, 6, 7, 6, 20, 16, -7, 2, -15, -12, -14, -15, -10, -10), 'R': (35, 29, 33, 4, 37, 33, 56, 50, 55, 29, 56, 67, 55, 62, 34, 60, 19, 35, 28, 33, 45, 27, 25, 15, 0, 5, 16, 13, 18, -4, -9, -6, -28, -35, -16, -21, -13, -29, -46, -30, -42, -28, -42, -25, -25, -35, -26, -46, -53, -38, -31, -26, -29, -43, -44, -53, -30, -24, -18, 5, -2, -18, -31, -32), 'Q': (6, 1, -8, -104, 69, 24, 88, 26, 14, 32, 60, -10, 20, 76, 57, 24, -2, 43, 32, 60, 72, 63, 43, 2, 1, -16, 22, 17, 25, 20, -13, -6, -14, -15, -2, -5, -1, -10, -20, -22, -30, -6, -13, -11, -16, -11, -16, -27, -36, -18, 0, -19, -15, -15, -21, -38, -39, -30, -31, -13, -31, -36, -34, -42), 'K': (4, 54, 47, -99, -99, 60, 83, -62, -32, 10, 55, 56, 56, 55, 10, 3, -62, 12, -57, 44, -67, 28, 37, -31, -55, 50, 11, -4, -19, 13, 0, -49, -55, -43, -52, -28, -51, -47, -8, -50, -47, -42, -43, -79, -64, -32, -29, -32, -4, 3, -14, -50, -57, -18, 13, 4, 17, 30, -3, -14, 6, -1, 40, 18)}
for k, table in pst.items():
    padrow = lambda row: (0,) + tuple((x + piece[k] for x in row)) + (0,)
    pst[k] = sum((padrow(table[i * 8:i * 8 + 8]) for i in range(8)), ())
    pst[k] = (0,) * 20 + pst[k] + (0,) * 20
K_MID, K_END = (pst['K'], tuple((piece['K'] + 70 - 10 * (abs(2 * (i // 10) - 11) + abs(2 * (i % 10) - 9)) for i in range(120))))
MATE_LOWER = 60000 - 13 * 929
MATE_UPPER = 60000 + 10 * 929
A1, H1, A8, H8 = (91, 98, 21, 28)
initial = '         \n         \n rnbqkbnr\n pppppppp\n ........\n ........\n ........\n ........\n PPPPPPPP\n RNBQKBNR\n         \n         \n'
N, E, S, W = (-10, 1, 10, -1)
directions = {'P': (N, N + N, N + W, N + E), 'N': (N + N + E, E + N + E, E + S + E, S + S + E, S + S + W, W + S + W, W + N + W, N + N + W), 'B': (N + E, S + E, S + W, N + W), 'R': (N, E, S, W), 'Q': (N, E, S, W, N + E, S + E, S + W, N + W), 'K': (N, E, S, W, N + E, S + E, S + W, N + W)}
QS = 40
QS_A = 140
Move = namedtuple('Move', 'i j prom')

class Position(namedtuple('Position', 'board score wc bc ep kp')):

    def __hash__(self):
        return hash((self.board, self.wc, self.bc, self.ep, self.kp))

    def __eq__(self, o):
        return self.board == o.board and self.ep == o.ep and (self.kp == o.kp) and (self.wc == o.wc) and (self.bc == o.bc)

    def __ne__(self, o):
        return not self.__eq__(o)

    def gen_moves(self):
        for i, p in enumerate(self.board):
            if p not in 'PNBRQK':
                continue
            for d in directions[p]:
                for j in count(i + d, d):
                    q = self.board[j]
                    if q in ' \nPNBRQK':
                        break
                    if p == 'P':
                        if d in (N, N + N) and q != '.':
                            break
                        if d == N + N and (i < A1 + N or self.board[i + N] != '.'):
                            break
                        if d in (N + W, N + E) and q == '.' and (j not in (self.ep, self.kp, self.kp - 1, self.kp + 1)):
                            break
                        if A8 <= j <= H8:
                            for prom in 'NBRQ':
                                yield Move(i, j, prom)
                            break
                    yield Move(i, j, '')
                    if p in 'PNK' or q in 'pnbrqk':
                        break
                    if i == A1 and self.board[j + E] == 'K' and self.wc[0]:
                        yield Move(j + E, j + W, '')
                    if i == H1 and self.board[j + W] == 'K' and self.wc[1]:
                        yield Move(j + W, j + E, '')

    def rotate(self, nullmove=False):
        return Position(self.board[::-1].swapcase(), -self.score, self.bc, self.wc, 119 - self.ep if self.ep and (not nullmove) else 0, 119 - self.kp if self.kp and (not nullmove) else 0)

    def move(self, move):
        i, j, prom = move
        p, q = (self.board[i], self.board[j])
        put = lambda board, i, p: board[:i] + p + board[i + 1:]
        board = self.board
        wc, bc, ep, kp = (self.wc, self.bc, 0, 0)
        score = self.score + self.value(move)
        board = put(board, j, board[i])
        board = put(board, i, '.')
        wc = (wc[0] and i != A1, wc[1] and i != H1)
        bc = (bc[0] and j != H8, bc[1] and j != A8)
        if p == 'K':
            wc = (False, False)
            if abs(j - i) == 2:
                kp = (i + j) // 2
                r = A1 if j < i else H1
                board = put(board, r, '.')
                board = put(board, kp, 'R')
        if p == 'P':
            if A8 <= j <= H8:
                board = put(board, j, prom)
            if j - i == 2 * N:
                ep = i + N
            if j == self.ep:
                board = put(board, j + S, '.')
        return Position(board[::-1].swapcase(), -score, bc, wc, 119 - ep if ep else 0, 119 - kp if kp else 0)

    def value(self, move):
        i, j, prom = move
        p, q = (self.board[i], self.board[j])
        score = pst[p][j] - pst[p][i]
        if q in 'pnbrqk':
            score += pst[q.upper()][119 - j]
        if abs(j - self.kp) < 2:
            score += pst['K'][119 - j]
        if p == 'K' and abs(i - j) == 2:
            score += pst['R'][(i + j) // 2]
            score -= pst['R'][A1 if j < i else H1]
        if p == 'P':
            if A8 <= j <= H8:
                score += pst[prom][j] - pst['P'][j]
            if j == self.ep:
                score += pst['P'][119 - (j + S)]
        return score

    def king_capture(self):
        return next((m for m in self.gen_moves() if self.board[m.j] == 'k' or abs(m.j - self.kp) < 2), None)
# SPDX-License-Identifier: GPL-3.0-only
# Independently adapted Sunfish search, 2026-11-10.
# The board and PST remain Thomas Ahle and contributors' pinned Sunfish.
# Local-comparison derivative of the independently authored 24k experiment.
LIMIT = 40000
class Stop(Exception):
    pass

class Searcher:
    def __init__(self):
        self.moves = {}

    def bound(self, pos, gamma, depth, root=False):
        self.nodes += 1
        if self.nodes > LIMIT:
            raise Stop
        depth = max(depth, 0)
        if pos.score <= -MATE_LOWER:
            return -MATE_UPPER
        key = pos, depth, root
        lo, hi = self.table.get(key, (-MATE_UPPER, MATE_UPPER))
        if lo >= gamma:
            return lo
        if hi < gamma:
            return hi
        if not root and depth and pos in self.history:
            return 0
        best = -MATE_UPPER
        killer = self.moves.get(pos)
        checked = depth == 0 and pos.rotate(True).king_capture()
        threshold = -MATE_UPPER if checked or root else QS-depth*QS_A
        def candidates():
            if not root and depth > 2 and abs(pos.score) < 500 and any(c in pos.board for c in "RBNQ"):
                yield None, -self.bound(pos.rotate(True), 1-gamma, depth-3)
            if not depth and not checked:
                yield None, pos.score
            if killer and pos.value(killer) >= threshold:
                yield killer, -self.bound(pos.move(killer), 1-gamma, depth-1)
            ordered = sorted(((pos.value(m), m) for m in (self.legal if root else pos.gen_moves())), reverse=True)
            for index, (value, move) in enumerate(ordered):
                if move == killer:
                    continue
                if value < threshold:
                    break
                if not checked and not root and depth <= 1 and pos.score+value < gamma:
                    yield None, MATE_UPPER if value >= MATE_LOWER else pos.score+value
                    break
                reduction = depth > 2 and index > 2 and value < 60
                child = pos.move(move)
                score = -self.bound(child, 1-gamma, depth-1-reduction)
                if reduction and score >= gamma:
                    score = -self.bound(child, 1-gamma, depth-1)
                yield move, score
        live = False
        for move, score in candidates():
            best = max(best, score)
            live |= move is not None and score > -MATE_UPPER
            if best >= gamma:
                if move and depth:
                    self.moves[pos] = move
                break
        if (depth or checked) and not live and all(pos.move(m).king_capture() for m in pos.gen_moves()):
            best = -MATE_LOWER if pos.rotate(True).king_capture() else 0
        self.table[key] = (best, hi) if best >= gamma else (lo, best)
        return best

    def choose(self, history, legal):
        self.nodes, self.table = 0, {}
        self.history = set(history[:-1])
        self.legal = legal
        pos = history[-1]
        # Never let an earlier game's or a non-legal root killer escape the root filter.
        if self.moves.get(pos) not in legal:
            self.moves.pop(pos, None)
        best = legal[0]
        gamma = 0
        try:
            for depth in range(1, 64):
                lower, upper = -MATE_UPPER, MATE_UPPER
                candidate = best
                for probe in range(40):
                    score = self.bound(pos, gamma, depth, True)
                    if score >= gamma:
                        lower = max(lower, score)
                        candidate = self.moves.get(pos, candidate)
                    else:
                        upper = min(upper, score)
                    if lower > upper:
                        break
                    if lower >= upper-15:
                        # Only a converged, non-crossing bracket can replace the move.
                        best = candidate
                        break
                    gamma = (lower+upper+1)//2
                # Commit only after a whole depth, not a partial fail-high probe.
        except Stop:
            pass
        if len(self.moves) > 40000:
            self.moves.clear()
        return best

# SPDX-License-Identifier: GPL-3.0-only
import json, os, urllib.request

def parse(c):
    return 91+ord(c[0])-97-10*(int(c[1])-1)

def decode(uci, black):
    i, j = parse(uci[:2]), parse(uci[2:4])
    return Move(119-i if black else i, 119-j if black else j, uci[4:].upper())

def from_board(board):
    score = sum(pst[p][i] if p.isupper() else -pst[p.upper()][119-i]
                for i, p in enumerate(board) if p.isalpha())
    return Position(board, score, (True, True), (True, True), 0, 0)

def choose_game(g, searcher):
    # Fix the king table for this entire search, then rescore its replay consistently.
    pieces = g["fen"].split()[0]
    bare = sum(c.isupper() for c in pieces)==1 or sum(c.islower() for c in pieces)==1
    pst["K"] = K_END if bare else K_MID
    # Replay the complete public history, including the eight opening plies.
    history = [from_board(initial)]
    for ply, uci in enumerate(g["moves"]):
        history.append(history[-1].move(decode(uci, ply%2)))
    ucis = sorted(g["legal_moves"])
    legal = [decode(u, len(g["moves"])%2) for u in ucis]
    return ucis[legal.index(searcher.choose(history, legal))]

def post(path, body):
    req = urllib.request.Request(os.environ["MAKEFUN_ENV_URL"]+path,
          json.dumps(body).encode(), {"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as response:
        return json.load(response)

def main():
    while True:
        g = post("/game", {})
        if g["status"] == "done":
            break
        searcher = Searcher()
        while g["status"] == "your_move":
            g = post("/move", {"game": g["game"], "move": choose_game(g, searcher)})
        print(g["game"], g["outcome"], g["reason"], flush=True)

if __name__ == "__main__":
    main()
